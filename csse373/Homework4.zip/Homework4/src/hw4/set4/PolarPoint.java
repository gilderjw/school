package hw4.set4;

public class PolarPoint extends Point {

	public PolarPoint(Point p) {
		super(p.x, p.y);
	}

	public double getR() {
		return 0;
	}
	
	public double getTheta() {
		return 0;
	}
}
