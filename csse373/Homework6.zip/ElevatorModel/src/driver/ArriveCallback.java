package driver;

import org.yakindu.scr.elevatormodeling.IElevatorModelingStatemachine;

public class ArriveCallback implements IElevatorModelingStatemachine.SCIElevatorOperationCallback {

	@Override
	public void arrive(long floor) {
		System.out.println("Arriving at floor: " + floor);
	}
}
